<?php
class userModel
{
    private $user;
    private $pass;

    public function setUser($user){
        $this->user = $user;
    }
}
