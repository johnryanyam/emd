<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Page</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gradient-to-r from-sky-500 to-sky-700 flex items-center justify-center min-h-screen">
    <div class="flex w-full max-w-5xl bg-white rounded-lg shadow-lg overflow-hidden">
        <div class="w-1/2 p-10">
            <h2 class="text-3xl font-bold text-center mb-6 text-gray-800">Sign in</h2>
            <div class="mt-4 flex justify-center space-x-4">
                <button class="p-2 border rounded-full text-blue-500 hover:bg-blue-100"><i class="fab fa-facebook-f"></i></button>
                <button class="p-2 border rounded-full text-red-500 hover:bg-red-100"><i class="fab fa-google"></i></button>
                <button class="p-2 border rounded-full text-black hover:bg-gray-200"><i class="fab fa-tiktok"></i></button>
            </div>
            <p class="text-center text-gray-500 mb-4">or use your account</p>
            <form id="loginForm" class="space-y-4">
                <div>
                    <input type="text" id="username" name="username" placeholder="Username" required 
                           class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-sky-500" 
                           autocomplete="username">
                </div>
                <div>
                    <input type="password" id="password" name="password" placeholder="Password" required 
                           class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-sky-500" 
                           autocomplete="current-password">
                </div>
                <div>
                    <button type="submit" class="w-full py-2 px-4 bg-sky-500 text-white rounded-md hover:bg-sky-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sky-500">Sign In</button>
                </div>
                <div class="text-center">
                    <a href="#" class="text-sm text-indigo-600 hover:text-indigo-900">Forgot your password?</a>
                </div>
            </form>
        </div>
        <div class="w-1/2 bg-gradient-to-r from-sky-600 to-sky-800 text-white flex items-center justify-center p-8">
            <div class="text-center">
                <h2 class="text-2xl font-bold mb-4">Hello, Friend!</h2>
                <p class="mb-4">Enter your personal details and start your journey with us</p>
                <a href="register.php" class="inline-block py-2 px-4 border border-white rounded-md hover:bg-white hover:text-sky-500">Sign Up</a>
            </div>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#loginForm').on('submit', function (e) {
                e.preventDefault();
                $.ajax({
                    type: "post",
                    url: "../../src/routes/routes.php",
                    data: {
                        type: "login",
                        user: $('#username').val(),
                        pass: $('#password').val(),
                    },
                    success: function (data) {
                        // Handle success
                    },
                });
            });
        });
    </script>
</body>
</html>
