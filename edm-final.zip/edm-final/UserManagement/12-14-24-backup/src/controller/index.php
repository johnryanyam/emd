<?php
include_once('database.php');

$db = new database();