<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-blue-100 min-h-screen">
    <div class="flex">
        <aside class="w-64 bg-blue-800 text-white h-screen">
            <div class="p-4">
                <h2 class="text-2xl font-bold">User Dashboard</h2>
            </div>
            <nav class="mt-10">
                <a href="userDashboard.php" class="block py-2.5 px-4 rounded transition duration-200 hover:bg-blue-700 hover:text-white">
                    <i class="fas fa-user"></i> Users
                </a>
                <a href="../../src/controller/logoutController.php" class="block py-2 px-4 rounded bg-red-500 hover:bg-red-700">Logout</a>
            </nav>
        </aside>
        <main class="flex-1 p-10">
            <h1 class="text-3xl font-bold mb-4">All Users</h1>
            <div class="bg-white p-6 rounded-lg shadow-md">
                <table class="min-w-full bg-white">
                    <thead>
                        <tr>
                            <th class="py-2">ID</th>
                            <th class="py-2">Username</th>
                            <th class="py-2">Email</th>
                            <th class="py-2">Role</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include_once('../../src/controller/userController.php');
                        $userController = new userController();
                        $users = $userController->getAllUsers(); // Fetch all users
                        foreach ($users as $user) {
                            if ($user['role'] !== 'admin') { // Exclude admins
                                echo "<tr>";
                                echo "<td class='border px-4 py-2'>{$user['id']}</td>";
                                echo "<td class='border px-4 py-2'>{$user['user']}</td>";
                                echo "<td class='border px-4 py-2'>{$user['email']}</td>";
                                echo "<td class='border px-4 py-2'>{$user['role']}</td>";
                                echo "</tr>";
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>