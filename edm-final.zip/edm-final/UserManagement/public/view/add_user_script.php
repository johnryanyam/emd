<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $role = $_POST['role'];

    // Here you would typically add code to insert the user into your database
    // Example:
    // $sql = "INSERT INTO users (username, role) VALUES ('$username', '$role')";
    // Execute the query...

    // Redirect back to the admin dashboard or show a success message
    header("Location: adminDashboard.php?success=User added successfully");
    exit();
}
?> 